<template>
  <div class="page-container">
    <h2 class="page-title">我的课程</h2>
    
    <!-- 通知公告 -->
    <div v-if="notifications.length > 0" class="notification-section">
      <el-alert
        v-for="item in notifications"
        :key="item.id"
        :title="item.title"
        :description="item.content"
        type="info"
        show-icon
        :closable="false"
        class="notification-item"
      >
        <template #default>
          <span style="color: #909399; font-size: 12px;">{{ item.createTime }}</span>
          <el-button type="primary" size="small" @click="viewRequirement(item)" style="margin-left: 10px;">查看详情</el-button>
        </template>
      </el-alert>
    </div>
    
    <div class="course-container">
      <!-- 已选课程 -->
      <div class="section">
        <h3 class="section-title">已选修课程</h3>
        <div v-if="selectedCourses.length > 0" class="course-list">
          <el-card v-for="course in selectedCourses" :key="course.id" class="course-card" shadow="hover">
            <template #header>
              <div class="card-header">
                <span class="course-name">{{ course.courseName }}</span>
                <el-tag type="success">已选修</el-tag>
              </div>
            </template>
            <div class="course-info">
              <p v-if="course.teacherName"><strong>授课教师：</strong>{{ course.teacherName }}</p>
              <p><strong>课程描述：</strong>{{ course.description || '暂无描述' }}</p>
              <p><strong>创建时间：</strong>{{ course.createTime }}</p>
            </div>
            <template #footer>
              <div class="card-footer">
                <el-button type="primary" size="small" @click="viewAssignments(course)">查看作业</el-button>
                <el-button type="warning" size="small" @click="viewCourseRequirements(course)">作业要求</el-button>
                <el-button type="danger" size="small" @click="handleCancel(course)">取消选课</el-button>
              </div>
            </template>
          </el-card>
        </div>
        <el-empty v-else description="您还没有选修任何课程" />
      </div>
      
      <!-- 可选课程 -->
      <div class="section">
        <h3 class="section-title">可选课程</h3>
        <div v-if="availableCourses.length > 0" class="course-list">
          <el-card v-for="course in availableCourses" :key="course.id" class="course-card available" shadow="hover">
            <template #header>
              <div class="card-header">
                <span class="course-name">{{ course.courseName }}</span>
                <el-tag type="info">可选</el-tag>
              </div>
            </template>
            <div class="course-info">
              <p v-if="course.teacherName"><strong>授课教师：</strong>{{ course.teacherName }}</p>
              <p><strong>课程描述：</strong>{{ course.description || '暂无描述' }}</p>
            </div>
            <template #footer>
              <div class="card-footer">
                <el-button type="primary" @click="handleSelect(course)">选修此课程</el-button>
              </div>
            </template>
          </el-card>
        </div>
        <el-empty v-else description="暂无可选课程" />
      </div>
    </div>

    <!-- 作业列表对话框 -->
    <el-dialog v-model="assignmentDialogVisible" :title="'课程作业 - ' + currentCourse?.courseName" width="850px" top="5vh">
      <div v-if="assignments.length > 0" class="assignment-list">
        <el-card 
          v-for="item in assignments" 
          :key="item.requirement.id" 
          class="assignment-card"
          :class="{ 'submitted': item.submitted, 'overdue': isOverdue(item.requirement.deadline) }"
        >
          <template #header>
            <div class="assignment-header">
              <div class="assignment-title-row">
                <span class="assignment-title">{{ item.requirement.title }}</span>
                <el-tag 
                  :type="getDeadlineTagType(item.requirement.deadline)" 
                  size="small"
                >
                  {{ getDeadlineText(item.requirement.deadline) }}
                </el-tag>
              </div>
              <div class="assignment-status-tags">
                <el-tag v-if="item.submitted" type="success" size="small">已提交</el-tag>
                <el-tag v-else type="info" size="small">未提交</el-tag>
                <el-tag v-if="item.report?.totalScore" type="warning" size="small" style="margin-left:4px">
                  得分: {{ item.report.totalScore }}
                </el-tag>
              </div>
            </div>
          </template>
          <div class="assignment-content">
            <p><strong>截止时间：</strong>{{ item.requirement.deadline || '未设置' }}</p>
            <p><strong>详细内容：</strong></p>
            <div class="content-text">{{ item.requirement.content || '无详细内容' }}</div>
            <div v-if="item.submitted" class="submission-info">
              <p><strong>已提交文件：</strong>{{ item.report?.fileName || '-' }}</p>
              <p><strong>提交时间：</strong>{{ item.report?.createTime || '-' }}</p>
            </div>
          </div>
          <template #footer>
            <div class="assignment-footer">
              <el-button 
                v-if="item.submitted" 
                type="success" 
                @click="goToEditAssignment(item)"
                :disabled="isOverdue(item.requirement.deadline)"
              >
                {{ isOverdue(item.requirement.deadline) ? '已截止' : '编辑提交' }}
              </el-button>
              <el-button 
                v-else 
                type="primary" 
                @click="goToSubmitAssignment(item)"
                :disabled="isOverdue(item.requirement.deadline)"
              >
                {{ isOverdue(item.requirement.deadline) ? '已截止' : '提交作业' }}
              </el-button>
              <el-button 
                v-if="item.submitted" 
                type="info" 
                size="small"
                @click="viewReportDetail(item.report)"
              >
                查看详情
              </el-button>
            </div>
          </template>
        </el-card>
      </div>
      <el-empty v-else description="暂无作业" />
      <template #footer>
        <el-button @click="assignmentDialogVisible = false">关闭</el-button>
      </template>
    </el-dialog>

    <!-- 提交/编辑作业对话框 -->
    <el-dialog 
      v-model="submitDialogVisible" 
      :title="submitDialogTitle" 
      width="650px" 
      top="5vh"
      @close="resetSubmitForm"
    >
      <el-form :model="submitForm" label-width="100px">
        <el-form-item label="作业标题">
          <el-input :model-value="currentAssignment?.requirement?.title" disabled />
        </el-form-item>
        <el-form-item label="成果文件" prop="files">
          <el-upload
            ref="uploadRef"
            :auto-upload="false"
            multiple
            :limit="20"
            :on-change="handleFileChange"
            :on-remove="handleFileRemove"
            v-model:file-list="fileList"
            accept=".doc,.docx,.pdf,.txt,.md,.py,.java,.js,.ts,.html,.css,.sql,.c,.cpp,.go,.rs,.php,.json,.xml,.yaml,.yml,.zip,.png,.jpg,.jpeg,.gif,.bmp,.webp"
            drag
          >
            <el-icon class="el-icon--upload"><UploadFilled /></el-icon>
            <div>将文件拖到此处，或<em>点击上传</em></div>
            <template #tip>
              <div class="el-upload__tip">
                支持文档、代码、截图、压缩包，可同时上传多个文件，总大小不超过50MB
              </div>
            </template>
          </el-upload>
        </el-form-item>
        <el-form-item v-if="fileCategories.length > 0" label="文件类型">
          <el-tag v-for="cat in fileCategories" :key="cat.type" :type="cat.color" style="margin-right:8px">
            {{ cat.icon }} {{ cat.type }} × {{ cat.count }}
          </el-tag>
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="submitDialogVisible = false">取消</el-button>
        <el-button type="primary" @click="handleSubmitAssignment" :loading="submitting" :disabled="fileList.length === 0">
          {{ isEditMode ? '更新提交' : '提交作业' }}
        </el-button>
      </template>
    </el-dialog>

    <!-- 报告详情对话框 -->
    <el-dialog v-model="detailDialogVisible" title="提交详情" width="700px">
      <div v-if="currentReport">
        <el-descriptions :column="2" border>
          <el-descriptions-item label="作业标题">{{ currentReport.requirementTitle || currentReport.title }}</el-descriptions-item>
          <el-descriptions-item label="学生">{{ currentReport.studentName }}</el-descriptions-item>
          <el-descriptions-item label="课程">{{ currentReport.courseName }}</el-descriptions-item>
          <el-descriptions-item label="文件名">{{ currentReport.fileName }}</el-descriptions-item>
          <el-descriptions-item label="状态">
            <el-tag :type="currentReport.status === 1 ? 'success' : 'warning'">
              {{ currentReport.statusName }}
            </el-tag>
          </el-descriptions-item>
          <el-descriptions-item label="提交时间">{{ currentReport.createTime }}</el-descriptions-item>
        </el-descriptions>
        
        <div v-if="currentReport.totalScore" class="score-section">
          <h4>评价结果</h4>
          <el-row :gutter="20">
            <el-col :span="6">
              <div class="score-item">
                <p class="label">完整性</p>
                <p class="value">{{ currentReport.completenessScore }}</p>
              </div>
            </el-col>
            <el-col :span="6">
              <div class="score-item">
                <p class="label">规范性</p>
                <p class="value">{{ currentReport.specificationScore }}</p>
              </div>
            </el-col>
            <el-col :span="6">
              <div class="score-item">
                <p class="label">知识点</p>
                <p class="value">{{ currentReport.knowledgeScore }}</p>
              </div>
            </el-col>
            <el-col :span="6">
              <div class="score-item total">
                <p class="label">总分</p>
                <p class="value">{{ currentReport.totalScore }}</p>
              </div>
            </el-col>
          </el-row>
          
          <div v-if="currentReport.aiEvaluation" class="ai-evaluation">
            <h5>AI评价详情</h5>
            <pre>{{ formatEvaluation(currentReport.aiEvaluation) }}</pre>
          </div>
          
          <div v-if="currentReport.manualEvaluation" class="manual-evaluation">
            <h5>教师评价</h5>
            <p>{{ currentReport.manualEvaluation }}</p>
          </div>
        </div>
      </div>
      <template #footer>
        <el-button @click="detailDialogVisible = false">关闭</el-button>
      </template>
    </el-dialog>

    <!-- 作业要求对话框 -->
    <el-dialog v-model="requirementDialogVisible" :title="'作业要求 - ' + currentCourse?.courseName" width="700px">
      <div v-if="courseRequirements.length > 0" class="requirement-list">
        <el-card 
          v-for="req in courseRequirements" 
          :key="req.id" 
          class="requirement-card"
          :class="{ 'overdue': isOverdue(req.deadline) }"
        >
          <template #header>
            <div class="requirement-header">
              <span class="requirement-title">{{ req.title }}</span>
              <el-tag :type="isOverdue(req.deadline) ? 'danger' : 'success'" size="small">
                {{ isOverdue(req.deadline) ? '已截止' : '进行中' }}
              </el-tag>
            </div>
          </template>
          <div class="requirement-content">
            <p><strong>截止时间：</strong>{{ req.deadline || '未设置' }}</p>
            <p><strong>详细内容：</strong></p>
            <div class="content-text">{{ req.content || '无详细内容' }}</div>
          </div>
        </el-card>
      </div>
      <el-empty v-else description="暂无作业要求" />
      <template #footer>
        <el-button @click="requirementDialogVisible = false">关闭</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { UploadFilled } from '@element-plus/icons-vue'
import { getAvailableCourses, selectCourse, cancelCourse, getMyCourses } from '../api/course'
import { getCourseRequirements } from '../api/reportRequirement'
import { getNotificationList, markAsRead } from '../api/notification'
import { getReport, getMySubmission, uploadMultipleReports, uploadReport, updateReport } from '../api/report'
import { useUserStoreHook } from '../stores'

const userStore = useUserStoreHook()
const selectedCourses = ref([])
const availableCourses = ref([])
const notifications = ref([])
const courseRequirements = ref([])

// 作业相关
const assignmentDialogVisible = ref(false)
const submitDialogVisible = ref(false)
const detailDialogVisible = ref(false)
const requirementDialogVisible = ref(false)
const currentCourse = ref(null)
const currentAssignment = ref(null)
const currentReport = ref(null)
const assignments = ref([])
const submitting = ref(false)
const uploadRef = ref()
const fileList = ref([])

const submitForm = ref({ files: [] })

const isEditMode = computed(() => !!currentAssignment.value?.submitted)
const submitDialogTitle = computed(() => isEditMode.value ? '编辑作业提交' : '提交作业')

// 文件类型分类
const fileCategories = computed(() => {
  const cats = {}
  fileList.value.forEach(f => {
    const ext = (f.name || '').split('.').pop()?.toLowerCase() || 'unknown'
    const info = getFileTypeInfo(ext)
    if (!cats[info.type]) cats[info.type] = { ...info, count: 0 }
    cats[info.type].count++
  })
  return Object.values(cats)
})

const getFileTypeInfo = (ext) => {
  const map = {
    doc: { type: '文档', icon: '📄', color: 'primary' },
    docx: { type: '文档', icon: '📄', color: 'primary' },
    pdf: { type: '文档', icon: '📄', color: 'primary' },
    txt: { type: '文档', icon: '📄', color: 'primary' },
    md: { type: '文档', icon: '📄', color: 'primary' },
    py: { type: '代码', icon: '💻', color: 'success' },
    java: { type: '代码', icon: '💻', color: 'success' },
    js: { type: '代码', icon: '💻', color: 'success' },
    ts: { type: '代码', icon: '💻', color: 'success' },
    html: { type: '代码', icon: '💻', color: 'success' },
    css: { type: '代码', icon: '💻', color: 'success' },
    sql: { type: '代码', icon: '💻', color: 'success' },
    png: { type: '截图', icon: '🖼️', color: 'warning' },
    jpg: { type: '截图', icon: '🖼️', color: 'warning' },
    jpeg: { type: '截图', icon: '🖼️', color: 'warning' },
    gif: { type: '截图', icon: '🖼️', color: 'warning' },
    zip: { type: '压缩包', icon: '📦', color: 'info' }
  }
  return map[ext] || { type: '其他', icon: '📁', color: '' }
}

const loadMyCourses = async () => {
  try {
    const res = await getMyCourses()
    selectedCourses.value = res.data || []
    loadAvailableCourses()
  } catch (error) {
    console.error(error)
  }
}

const loadAvailableCourses = async () => {
  try {
    const res = await getAvailableCourses()
    const selectedIds = selectedCourses.value.map(c => c.id)
    availableCourses.value = (res.data || []).filter(c => !selectedIds.includes(c.id))
  } catch (error) {
    console.error(error)
  }
}

const loadNotifications = async () => {
  try {
    const res = await getNotificationList({ pageNum: 1, pageSize: 10 })
    notifications.value = (res.data?.records || []).filter(n => n.type === 1 && n.isRead === 0)
  } catch (error) {
    console.error(error)
  }
}

const viewRequirement = async (notification) => {
  try {
    await markAsRead(notification.id)
    const course = selectedCourses.value.find(c => notification.relatedId)
    if (course) {
      await viewCourseRequirements(course)
    }
    notifications.value = notifications.value.filter(n => n.id !== notification.id)
  } catch (error) {
    console.error(error)
  }
}

// 查看课程作业列表
const viewAssignments = async (course) => {
  currentCourse.value = course
  try {
    const res = await getCourseRequirements(course.id)
    const requirements = res.data || []
    
    // 检查每个作业的提交状态
    const items = await Promise.all(requirements.map(async (req) => {
      try {
        const subRes = await getMySubmission(req.id)
        return {
          requirement: req,
          submitted: true,
          report: subRes.data
        }
      } catch {
        return {
          requirement: req,
          submitted: false,
          report: null
        }
      }
    }))
    
    assignments.value = items
    assignmentDialogVisible.value = true
  } catch (error) {
    console.error(error)
    ElMessage.error('获取作业列表失败')
  }
}

const viewCourseRequirements = async (course) => {
  currentCourse.value = course
  try {
    const res = await getCourseRequirements(course.id)
    courseRequirements.value = res.data || []
    requirementDialogVisible.value = true
  } catch (error) {
    console.error(error)
  }
}

const isOverdue = (deadline) => {
  if (!deadline) return false
  return new Date(deadline) < new Date()
}

const getDeadlineTagType = (deadline) => {
  if (!deadline) return 'info'
  return new Date(deadline) < new Date() ? 'danger' : 'success'
}

const getDeadlineText = (deadline) => {
  if (!deadline) return '无截止时间'
  return new Date(deadline) < new Date() ? '已截止' : '进行中'
}

// 提交作业
const goToSubmitAssignment = (item) => {
  currentAssignment.value = item
  submitForm.value = { files: [] }
  fileList.value = []
  submitDialogVisible.value = true
}

// 编辑已提交的作业
const goToEditAssignment = (item) => {
  currentAssignment.value = item
  submitForm.value = { files: [] }
  fileList.value = []
  submitDialogVisible.value = true
}

const handleFileChange = () => {
  submitForm.value.files = fileList.value.map(f => f.raw).filter(Boolean)
}

const handleFileRemove = () => {
  submitForm.value.files = fileList.value.map(f => f.raw).filter(Boolean)
}

const resetSubmitForm = () => {
  submitForm.value = { files: [] }
  fileList.value = []
  currentAssignment.value = null
}

const handleSubmitAssignment = async () => {
  if (fileList.value.length === 0) {
    ElMessage.warning('请选择至少一个文件')
    return
  }

  submitting.value = true
  try {
    const req = currentAssignment.value.requirement
    const formData = new FormData()
    formData.append('studentId', userStore.userInfo.userId)
    formData.append('courseId', req.courseId)
    formData.append('requirementId', req.id)
    formData.append('title', req.title)

    const files = fileList.value.map(f => f.raw).filter(Boolean)
    
    if (isEditMode.value) {
      // 编辑模式：更新已有报告
      const reportId = currentAssignment.value.report.id
      if (files.length > 1) {
        files.forEach(file => formData.append('files', file))
        await updateReport(reportId, formData)
      } else {
        formData.append('file', files[0])
        await updateReport(reportId, formData)
      }
      ElMessage.success('作业已更新')
    } else {
      // 新提交
      if (files.length > 1) {
        files.forEach(file => formData.append('files', file))
        await uploadMultipleReports(formData)
      } else {
        formData.append('file', files[0])
        await uploadReport(formData)
      }
      ElMessage.success('作业提交成功')
    }

    submitDialogVisible.value = false
    resetSubmitForm()
    
    // 刷新作业列表
    if (currentCourse.value) {
      await viewAssignments(currentCourse.value)
    }
  } catch (error) {
    console.error(error)
  } finally {
    submitting.value = false
  }
}

// 查看报告详情
const viewReportDetail = async (report) => {
  if (!report?.id) return
  try {
    const res = await getReport(report.id)
    currentReport.value = res.data
    detailDialogVisible.value = true
  } catch (error) {
    console.error(error)
  }
}

const formatEvaluation = (jsonStr) => {
  try {
    return JSON.stringify(JSON.parse(jsonStr), null, 2)
  } catch {
    return jsonStr
  }
}

const handleSelect = async (course) => {
  await ElMessageBox.confirm(`确定选修「${course.courseName}」吗？`, '选课确认', { type: 'info' })
  try {
    await selectCourse(course.id)
    ElMessage.success('选课成功')
    loadMyCourses()
  } catch (error) {
    console.error(error)
  }
}

const handleCancel = async (course) => {
  await ElMessageBox.confirm(`确定取消选修「${course.courseName}」吗？`, '取消选课', { type: 'warning' })
  try {
    await cancelCourse(course.id)
    ElMessage.success('已取消选课')
    loadMyCourses()
  } catch (error) {
    console.error(error)
  }
}

onMounted(() => {
  loadMyCourses()
  loadNotifications()
})
</script>

<style scoped>
.notification-section {
  margin-bottom: 20px;
}

.notification-item {
  margin-bottom: 10px;
}

.course-container {
  display: flex;
  flex-direction: column;
  gap: 30px;
}

.section-title {
  margin-bottom: 16px;
  padding-bottom: 8px;
  border-bottom: 2px solid #409eff;
  color: #303133;
}

.course-list {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
  gap: 16px;
}

.course-card {
  transition: transform 0.2s;
}

.course-card:hover {
  transform: translateY(-4px);
}

.course-card.available {
  border: 1px dashed #409eff;
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.course-name {
  font-size: 16px;
  font-weight: bold;
  color: #303133;
}

.course-info p {
  margin: 8px 0;
  font-size: 14px;
  color: #606266;
}

.card-footer {
  display: flex;
  justify-content: center;
  gap: 16px;
}

/* 作业列表 */
.assignment-list {
  display: flex;
  flex-direction: column;
  gap: 16px;
  max-height: 60vh;
  overflow-y: auto;
}

.assignment-card {
  border-left: 4px solid #409eff;
}

.assignment-card.submitted {
  border-left-color: #67c23a;
}

.assignment-card.overdue {
  border-left-color: #f56c6c;
  opacity: 0.85;
}

.assignment-header {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  gap: 12px;
}

.assignment-title-row {
  display: flex;
  align-items: center;
  gap: 10px;
}

.assignment-title {
  font-weight: bold;
  color: #303133;
  font-size: 15px;
}

.assignment-status-tags {
  display: flex;
  align-items: center;
  flex-shrink: 0;
}

.assignment-content p {
  margin: 8px 0;
  font-size: 14px;
  color: #606266;
}

.content-text {
  background: #f5f7fa;
  padding: 12px;
  border-radius: 4px;
  white-space: pre-wrap;
  line-height: 1.8;
  max-height: 150px;
  overflow-y: auto;
}

.submission-info {
  margin-top: 12px;
  padding: 10px 14px;
  background: #f0f9eb;
  border-radius: 4px;
}

.submission-info p {
  margin: 4px 0;
  font-size: 13px;
  color: #67c23a;
}

.assignment-footer {
  display: flex;
  justify-content: flex-end;
  gap: 8px;
}

/* 作业要求 */
.requirement-list {
  display: flex;
  flex-direction: column;
  gap: 16px;
  max-height: 500px;
  overflow-y: auto;
}

.requirement-card {
  border-left: 4px solid #409eff;
}

.requirement-card.overdue {
  border-left-color: #f56c6c;
  opacity: 0.8;
}

.requirement-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.requirement-title {
  font-weight: bold;
  color: #303133;
}

.requirement-content p {
  margin: 8px 0;
  font-size: 14px;
  color: #606266;
}

/* 评分 */
.score-section {
  margin-top: 20px;
}

.score-section h4 {
  margin-bottom: 16px;
  color: #303133;
}

.score-item {
  text-align: center;
  padding: 16px;
  background: #f5f7fa;
  border-radius: 4px;
}

.score-item .label {
  font-size: 14px;
  color: #909399;
  margin-bottom: 8px;
}

.score-item .value {
  font-size: 24px;
  font-weight: bold;
  color: #303133;
}

.score-item.total .value {
  color: #409eff;
}

.ai-evaluation, .manual-evaluation {
  margin-top: 16px;
  padding: 16px;
  background: #f5f7fa;
  border-radius: 4px;
}

.ai-evaluation h5, .manual-evaluation h5 {
  margin-bottom: 8px;
  color: #606266;
}

.ai-evaluation pre {
  white-space: pre-wrap;
  word-break: break-all;
  font-family: inherit;
  margin: 0;
}
</style>
