package com.training.service;

import com.alibaba.excel.EasyExcel;
import com.training.common.Result;
import com.training.dto.ScoreDistribution;
import com.training.dto.StatisticsDTO;
import com.training.entity.SysClass;
import com.training.entity.SysUser;
import com.training.entity.TrainingReport;
import com.training.mapper.EvaluationRecordMapper;
import com.training.mapper.SysClassMapper;
import com.training.mapper.SysUserMapper;
import com.training.mapper.TrainingReportMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class StatisticsService {
    
    private final SysClassMapper classMapper;
    private final SysUserMapper userMapper;
    private final TrainingReportMapper reportMapper;
    private final EvaluationRecordMapper evaluationMapper;
    
    public Result<StatisticsDTO> getClassStatistics(Long classId, Long currentUserId, Integer currentRole) {
        // 学生只能查看自己所在班级的统计
        if (currentRole != null && currentRole == com.training.common.Constants.ROLE_STUDENT) {
            SysUser student = userMapper.selectById(currentUserId);
            if (student == null || student.getClassId() == null || !student.getClassId().equals(classId)) {
                return Result.error("只能查看自己班级的统计信息");
            }
        }
        
        SysClass sysClass = classMapper.selectById(classId);
        if (sysClass == null) {
            return Result.error("班级不存在");
        }
        
        StatisticsDTO dto = new StatisticsDTO();
        dto.setClassId(classId);
        dto.setClassName(sysClass.getClassName());
        
        // 统计学生人数
        List<SysUser> students = userMapper.selectByClassId(classId);
        dto.setTotalStudents(students.size());
        
        // 统计已评价的报告
        List<Map<String, Object>> scores = evaluationMapper.selectAllScores(classId);
        
        dto.setTotalReports(scores.size());
        
        int evaluatedCount = 0;
        BigDecimal totalScore = BigDecimal.ZERO;
        BigDecimal maxScore = BigDecimal.ZERO;
        BigDecimal minScore = BigDecimal.valueOf(100);
        
        for (Map<String, Object> score : scores) {
            Object totalObj = score.get("total_score");
            if (totalObj != null) {
                BigDecimal scoreValue = new BigDecimal(totalObj.toString());
                evaluatedCount++;
                totalScore = totalScore.add(scoreValue);
                
                if (scoreValue.compareTo(maxScore) > 0) {
                    maxScore = scoreValue;
                }
                if (scoreValue.compareTo(minScore) < 0) {
                    minScore = scoreValue;
                }
            }
        }
        
        dto.setEvaluatedReports(evaluatedCount);
        
        if (evaluatedCount > 0) {
            dto.setAvgScore(totalScore.divide(BigDecimal.valueOf(evaluatedCount), 2, RoundingMode.HALF_UP));
        } else {
            dto.setAvgScore(BigDecimal.ZERO);
        }
        
        dto.setMaxScore(evaluatedCount > 0 ? maxScore : BigDecimal.ZERO);
        dto.setMinScore(evaluatedCount > 0 ? minScore : BigDecimal.ZERO);
        
        // 计算分数段分布
        dto.setScoreDistribution(calculateScoreDistribution(scores));
        
        // 成绩列表（将 MyBatis 自动转换的驼峰 key 还原为下划线格式，确保前端匹配）
        List<Map<String, Object>> normalizedScores = new ArrayList<>();
        for (Map<String, Object> score : scores) {
            Map<String, Object> normalized = new LinkedHashMap<>();
            for (Map.Entry<String, Object> entry : score.entrySet()) {
                String key = entry.getKey();
                // 将 camelCase 转回 snake_case
                String snakeKey = key.replaceAll("([a-z])([A-Z])", "$1_$2").toLowerCase();
                normalized.put(snakeKey, entry.getValue());
            }
            normalizedScores.add(normalized);
        }
        dto.setScoreList(normalizedScores);
        
        return Result.success(dto);
    }
    
    public Result<List<Map<String, Object>>> getAllClassesStatistics(Long currentUserId, Integer currentRole) {
        // 学生只能看到自己所在班级
        if (currentRole != null && currentRole == com.training.common.Constants.ROLE_STUDENT) {
            SysUser student = userMapper.selectById(currentUserId);
            if (student == null || student.getClassId() == null) {
                return Result.error("未分配班级");
            }
            SysClass sysClass = classMapper.selectById(student.getClassId());
            if (sysClass == null) {
                return Result.error("班级不存在");
            }
            List<Map<String, Object>> result = new ArrayList<>();
            Map<String, Object> stat = buildClassStat(sysClass.getId(), sysClass.getClassName());
            result.add(stat);
            return Result.success(result);
        }
        
        List<SysClass> classes = classMapper.selectList(null);
        
        List<Map<String, Object>> result = new ArrayList<>();
        
        for (SysClass sysClass : classes) {
            Map<String, Object> stat = buildClassStat(sysClass.getId(), sysClass.getClassName());
            result.add(stat);
        }
        
        return Result.success(result);
    }
    
    private Map<String, Object> buildClassStat(Long classId, String className) {
        Map<String, Object> stat = new HashMap<>();
        stat.put("classId", classId);
        stat.put("className", className);
        
        List<Map<String, Object>> scores = evaluationMapper.selectAllScores(classId);
        
        int evaluatedCount = 0;
        BigDecimal totalScore = BigDecimal.ZERO;
        BigDecimal maxScore = BigDecimal.ZERO;
        BigDecimal minScore = BigDecimal.valueOf(100);
        
        for (Map<String, Object> score : scores) {
            Object totalObj = score.get("total_score");
            if (totalObj != null) {
                BigDecimal scoreValue = new BigDecimal(totalObj.toString());
                evaluatedCount++;
                totalScore = totalScore.add(scoreValue);
                
                if (scoreValue.compareTo(maxScore) > 0) {
                    maxScore = scoreValue;
                }
                if (scoreValue.compareTo(minScore) < 0) {
                    minScore = scoreValue;
                }
            }
        }
        
        stat.put("totalReports", scores.size());
        stat.put("evaluatedReports", evaluatedCount);
        stat.put("avgScore", evaluatedCount > 0 
                ? totalScore.divide(BigDecimal.valueOf(evaluatedCount), 2, RoundingMode.HALF_UP) 
                : BigDecimal.ZERO);
        stat.put("maxScore", evaluatedCount > 0 ? maxScore : BigDecimal.ZERO);
        stat.put("minScore", evaluatedCount > 0 ? minScore : BigDecimal.ZERO);
        
        return stat;
    }
    
    private List<ScoreDistribution> calculateScoreDistribution(List<Map<String, Object>> scores) {
        int[] ranges = {0, 0, 0, 0, 0}; // 0-60, 60-70, 70-80, 80-90, 90-100
        
        for (Map<String, Object> score : scores) {
            Object totalObj = score.get("total_score");
            if (totalObj != null) {
                BigDecimal scoreValue = new BigDecimal(totalObj.toString());
                double s = scoreValue.doubleValue();
                
                if (s < 60) {
                    ranges[0]++;
                } else if (s < 70) {
                    ranges[1]++;
                } else if (s < 80) {
                    ranges[2]++;
                } else if (s < 90) {
                    ranges[3]++;
                } else {
                    ranges[4]++;
                }
            }
        }
        
        int total = scores.size();
        List<ScoreDistribution> distributions = new ArrayList<>();
        String[] labels = {"0-60分", "60-70分", "70-80分", "80-90分", "90-100分"};
        
        for (int i = 0; i < 5; i++) {
            ScoreDistribution dist = new ScoreDistribution();
            dist.setRange(labels[i]);
            dist.setCount(ranges[i]);
            dist.setPercentage(total > 0 ? (double) Math.round(ranges[i] * 100.0 / total) : 0.0);
            distributions.add(dist);
        }
        
        return distributions;
    }
    
    public Result<Map<String, Object>> exportScores(Long classId, String exportPath, Long currentUserId, Integer currentRole) {
        // 学生只能导出自己班级的成绩
        if (currentRole != null && currentRole == com.training.common.Constants.ROLE_STUDENT) {
            SysUser student = userMapper.selectById(currentUserId);
            if (student == null || student.getClassId() == null || !student.getClassId().equals(classId)) {
                return Result.error("只能导出自己班级的成绩");
            }
        }
        
        Result<StatisticsDTO> statResult = getClassStatistics(classId, currentUserId, currentRole);
        if (statResult.getCode() != 200) {
            return Result.error("导出失败");
        }
        
        StatisticsDTO dto = statResult.getData();
        
        List<Map<String, Object>> rawData = dto.getScoreList();
        
        // 写入Excel
        String filename = dto.getClassName() + "_成绩单_" + System.currentTimeMillis() + ".xlsx";
        String fullPath = exportPath + "/" + filename;
        
        try {
            // 创建目录
            new java.io.File(exportPath).mkdirs();
            
            // 将 Map 数据转为 List<List<Object>>，确保列顺序和 head 一致
            DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
            List<List<Object>> rows = new ArrayList<>();
            for (Map<String, Object> map : rawData) {
                List<Object> row = new ArrayList<>();
                row.add(map.get("username"));
                row.add(map.get("student_name"));
                row.add(map.get("class_name"));
                row.add(map.get("report_title"));
                row.add(map.get("completeness_score"));
                row.add(map.get("specification_score"));
                row.add(map.get("knowledge_score"));
                row.add(map.get("total_score"));
                
                // 格式化评价时间为字符串，避免 EasyExcel 写入 Timestamp 导致列宽不足显示为星号
                Object timeObj = map.get("evaluate_time");
                String timeStr = "";
                if (timeObj != null) {
                    if (timeObj instanceof LocalDateTime) {
                        timeStr = ((LocalDateTime) timeObj).format(dtf);
                    } else if (timeObj instanceof java.util.Date) {
                        LocalDateTime ldt = ((java.util.Date) timeObj).toInstant()
                                .atZone(ZoneId.systemDefault()).toLocalDateTime();
                        timeStr = ldt.format(dtf);
                    } else if (timeObj instanceof java.sql.Timestamp) {
                        LocalDateTime ldt = ((java.sql.Timestamp) timeObj).toLocalDateTime();
                        timeStr = ldt.format(dtf);
                    } else {
                        timeStr = timeObj.toString();
                    }
                }
                row.add(timeStr);
                rows.add(row);
            }
            
            EasyExcel.write(fullPath)
                    .head(createHeaders())
                    .sheet("成绩单")
                    .doWrite(rows);
            
            Map<String, Object> result = new HashMap<>();
            result.put("filename", filename);
            result.put("path", fullPath);
            
            return Result.success(result);
        } catch (Exception e) {
            return Result.error("导出失败: " + e.getMessage());
        }
    }
    
    private List<List<String>> createHeaders() {
        List<List<String>> headers = new ArrayList<>();
        headers.add(Arrays.asList("学号"));
        headers.add(Arrays.asList("姓名"));
        headers.add(Arrays.asList("班级"));
        headers.add(Arrays.asList("报告标题"));
        headers.add(Arrays.asList("完整性得分"));
        headers.add(Arrays.asList("规范性得分"));
        headers.add(Arrays.asList("知识点得分"));
        headers.add(Arrays.asList("总分"));
        headers.add(Arrays.asList("评价时间"));
        return headers;
    }
}
