<template>
  <div class="page-container">
    <h2 class="page-title">
      {{ getPageTitle() }}
    </h2>
    
    <div class="search-form" v-if="!isStudent">
      <el-form :inline="true" :model="searchForm">
        <el-form-item label="课程">
          <el-select v-model="searchForm.courseId" placeholder="全部课程" clearable style="width: 210px">
            <el-option v-for="c in allCourses" :key="c.id" :label="c.courseName" :value="c.id" />
          </el-select>
        </el-form-item>
        <el-form-item label="班级">
          <el-select v-model="searchForm.classId" placeholder="全部班级" clearable style="width: 210px">
            <el-option v-for="c in classes" :key="c.id" :label="c.className" :value="c.id" />
          </el-select>
        </el-form-item>
        <el-form-item label="状态">
          <el-select v-model="searchForm.status" placeholder="全部" clearable style="width: 150px">
            <el-option label="待评价" :value="0" />
            <el-option label="已评价" :value="1" />
          </el-select>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="handleSearch">查询</el-button>
          <el-button @click="handleReset">重置</el-button>
        </el-form-item>
      </el-form>
    </div>
    
    <div class="table-container">
      <el-table :data="tableData" stripe v-loading="loading">
        <el-table-column prop="studentName" label="学生" />
        <el-table-column prop="className" label="班级" />
        <el-table-column prop="courseName" label="课程" width="180" />
        <el-table-column prop="title" label="报告标题" show-overflow-tooltip />
        <el-table-column prop="fileName" label="文件名" show-overflow-tooltip />
        <el-table-column prop="statusName" label="状态">
          <template #default="{ row }">
            <el-tag :type="row.status === 1 ? 'success' : 'warning'">{{ row.statusName }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="totalScore" label="总分" width="100">
          <template #default="{ row }">
            <span v-if="row.totalScore" class="score">{{ row.totalScore }}</span>
            <span v-else class="no-score">-</span>
          </template>
        </el-table-column>
        <el-table-column prop="createTime" label="提交时间" width="160">
          <template #default="{ row }">
            {{ formatTime(row.createTime) }}
          </template>
        </el-table-column>
        <el-table-column label="操作" width="240">
          <template #default="{ row }">
            <div class="action-buttons">
              <el-button type="primary" size="small" @click="handleView(row)">查看详情</el-button>
              <el-button type="success" size="small" @click="handleDownload(row)">下载</el-button>
              <el-button type="danger" size="small" @click="handleDelete(row)">删除</el-button>
            </div>
          </template>
        </el-table-column>
      </el-table>
      
      <div class="pagination-container">
        <el-pagination
          v-model:current-page="pagination.pageNum"
          v-model:page-size="pagination.pageSize"
          :total="pagination.total"
          :page-sizes="[10, 20, 50]"
          layout="total, sizes, prev, pager, next"
          @size-change="loadData"
          @current-change="loadData"
        />
      </div>
    </div>
    
    <el-dialog v-model="detailVisible" title="报告详情" width="700px">
      <div v-if="currentReport">
        <el-descriptions :column="2" border>
          <el-descriptions-item label="报告标题">{{ currentReport.title }}</el-descriptions-item>
          <el-descriptions-item label="学生">{{ currentReport.studentName }}</el-descriptions-item>
          <el-descriptions-item label="班级">{{ currentReport.className }}</el-descriptions-item>
          <el-descriptions-item label="课程">{{ currentReport.courseName }}</el-descriptions-item>
          <el-descriptions-item label="文件名">{{ currentReport.fileName }}</el-descriptions-item>
          <el-descriptions-item label="状态">
            <el-tag :type="currentReport.status === 1 ? 'success' : 'warning'">
              {{ currentReport.statusName }}
            </el-tag>
          </el-descriptions-item>
          <el-descriptions-item label="提交时间">{{ currentReport.createTime }}</el-descriptions-item>
        </el-descriptions>
        
        <div v-if="currentReport.totalScore" class="score-section">
          <h4>评价结果</h4>
          <el-row :gutter="20">
            <el-col :span="6">
              <div class="score-item">
                <p class="label">完整性</p>
                <p class="value">{{ currentReport.completenessScore }}</p>
              </div>
            </el-col>
            <el-col :span="6">
              <div class="score-item">
                <p class="label">规范性</p>
                <p class="value">{{ currentReport.specificationScore }}</p>
              </div>
            </el-col>
            <el-col :span="6">
              <div class="score-item">
                <p class="label">知识点</p>
                <p class="value">{{ currentReport.knowledgeScore }}</p>
              </div>
            </el-col>
            <el-col :span="6">
              <div class="score-item total">
                <p class="label">总分</p>
                <p class="value">{{ currentReport.totalScore }}</p>
              </div>
            </el-col>
          </el-row>
          
          <div v-if="currentReport.aiEvaluation" class="ai-evaluation">
            <h5>AI评价详情</h5>
            <pre>{{ formatEvaluation(currentReport.aiEvaluation) }}</pre>
          </div>
          
          <div v-if="currentReport.manualEvaluation" class="manual-evaluation">
            <h5>教师评价</h5>
            <p>{{ currentReport.manualEvaluation }}</p>
          </div>
        </div>
      </div>
      <template #footer>
        <el-button @click="detailVisible = false">关闭</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, reactive, computed, onMounted } from 'vue'
import { useRoute } from 'vue-router'
import { ElMessage, ElMessageBox } from 'element-plus'
import { getReportList, deleteReport, getReport, downloadReport } from '../api/report'
import { getAllClasses } from '../api/class'
import { getCourseList } from '../api/course'
import { useUserStoreHook } from '../stores'

const route = useRoute()
const userStore = useUserStoreHook()
const isStudent = computed(() => userStore.userInfo?.role === 3)
const currentCourseId = computed(() => route.query.courseId ? Number(route.query.courseId) : null)
const currentClassId = computed(() => route.query.classId ? Number(route.query.classId) : null)

const loading = ref(false)
const detailVisible = ref(false)
const classes = ref([])
const allCourses = ref([])
const currentReport = ref(null)

const searchForm = reactive({ courseId: null, classId: null, status: null })
const pagination = reactive({ pageNum: 1, pageSize: 10, total: 0 })
const tableData = ref([])

// 如果从课程页面跳转过来，获取课程名称
const courseName = computed(() => {
  const course = allCourses.value.find(c => c.id === currentCourseId.value)
  return course?.courseName || ''
})

// 如果从班级页面跳转过来，获取班级名称
const className = computed(() => {
  const cls = classes.value.find(c => c.id === currentClassId.value)
  return cls?.className || ''
})

// 获取页面标题
const getPageTitle = () => {
  if (currentCourseId.value || currentClassId.value) {
    const parts = []
    if (courseName.value) parts.push(courseName.value)
    if (className.value) parts.push(className.value)
    if (parts.length > 0) {
      return parts.join(' - ') + ' - 报告列表'
    }
    return '课程 - 报告列表'
  }
  return isStudent.value ? '我的实训报告' : '报告管理'
}

const loadData = async () => {
  loading.value = true
  try {
    let params = { pageNum: pagination.pageNum, pageSize: pagination.pageSize }
    
    if (isStudent.value) {
      // 学生：只能查看自己的报告，如果有 courseId 则按课程过滤
      params.courseId = currentCourseId.value || undefined
    } else {
      // 教师/管理员：如果从课程页面跳转过来，只显示该课程的报告
      if (currentCourseId.value) {
        params.courseId = currentCourseId.value
      }
      // 如果从班级页面跳转过来，按班级过滤
      if (currentClassId.value) {
        params.classId = currentClassId.value
      }
      // 如果没有特殊过滤条件，使用搜索表单的条件
      if (!currentCourseId.value && !currentClassId.value) {
        params = { ...searchForm, ...pagination }
      }
    }
    
    const res = await getReportList(params)
    tableData.value = res.data.records
    pagination.total = res.data.total
  } catch (error) {
    console.error(error)
  } finally {
    loading.value = false
  }
}

const loadClasses = async () => {
  try {
    const res = await getAllClasses()
    classes.value = res.data || []
  } catch (error) {
    console.error(error)
  }
}

const loadAllCourses = async () => {
  try {
    const res = await getCourseList({ pageNum: 1, pageSize: 100 })
    allCourses.value = res.data.records || []
  } catch (error) {
    console.error(error)
  }
}

const handleSearch = () => {
  pagination.pageNum = 1
  loadData()
}

const handleReset = () => {
  searchForm.courseId = null
  searchForm.classId = null
  searchForm.status = null
  handleSearch()
}

const handleView = async (row) => {
  try {
    const res = await getReport(row.id)
    currentReport.value = res.data
    detailVisible.value = true
  } catch (error) {
    console.error(error)
  }
}

const handleDownload = async (row) => {
  try {
    const res = await downloadReport(row.id)
    // 检查是否返回了错误JSON（文件不存在等情况）
    if (res.data instanceof Blob && res.data.type === 'application/json') {
      const text = await res.data.text()
      const json = JSON.parse(text)
      ElMessage.error(json.message || '下载失败')
      return
    }
    // 从响应头或 row 数据中获取文件名
    const contentDisposition = res.headers['content-disposition']
    let filename = row.fileName || row.file_name || 'report'
    if (contentDisposition) {
      const match = contentDisposition.match(/filename[^;=\n]*=((['"]).*?\2|[^;\n]*)/)
      if (match && match[1]) {
        filename = decodeURIComponent(match[1].replace(/['"]/g, ''))
      }
    }
    const url = window.URL.createObjectURL(new Blob([res.data]))
    const link = document.createElement('a')
    link.href = url
    link.download = filename
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
    window.URL.revokeObjectURL(url)
    ElMessage.success('下载成功')
  } catch (error) {
    console.error(error)
    // 尝试从错误响应中提取消息
    if (error.response?.data instanceof Blob) {
      try {
        const text = await error.response.data.text()
        const json = JSON.parse(text)
        ElMessage.error(json.message || '下载失败')
        return
      } catch {}
    }
    if (error.response?.status === 404) {
      ElMessage.error('文件不存在或已被删除')
    } else {
      ElMessage.error('下载失败')
    }
  }
}

const handleDelete = async (row) => {
  await ElMessageBox.confirm('确定删除该报告？', '提示', { type: 'warning' })
  try {
    await deleteReport(row.id)
    ElMessage.success('删除成功')
    loadData()
  } catch (error) {
    console.error(error)
  }
}

const formatTime = (timeStr) => {
  if (!timeStr) return '-'
  const date = new Date(timeStr)
  const month = String(date.getMonth() + 1).padStart(2, '0')
  const day = String(date.getDate()).padStart(2, '0')
  const hours = String(date.getHours()).padStart(2, '0')
  const minutes = String(date.getMinutes()).padStart(2, '0')
  const seconds = String(date.getSeconds()).padStart(2, '0')
  return `${month}-${day} ${hours}:${minutes}:${seconds}`
}

const formatEvaluation = (jsonStr) => {
  try {
    return JSON.stringify(JSON.parse(jsonStr), null, 2)
  } catch {
    return jsonStr
  }
}

onMounted(() => {
  loadData()
  loadClasses()
  loadAllCourses()
})
</script>

<style scoped>
.page-container {
  overflow: hidden;
}

.toolbar {
  margin-bottom: 16px;
}

:deep(.el-table) {
  overflow: hidden;
}

:deep(.el-table__body-wrapper) {
  overflow-x: hidden !important;
}

.action-buttons {
  display: flex;
  flex-wrap: nowrap;
  gap: 4px;
}

.score {
  font-weight: bold;
  color: #409eff;
}

.no-score {
  color: #999;
}

.score-section {
  margin-top: 20px;
  
  h4 {
    margin-bottom: 16px;
    color: #303133;
  }
}

.score-item {
  text-align: center;
  padding: 16px;
  background: #f5f7fa;
  border-radius: 4px;
  
  .label {
    font-size: 14px;
    color: #909399;
    margin-bottom: 8px;
  }
  
  .value {
    font-size: 24px;
    font-weight: bold;
    color: #303133;
  }
  
  &.total .value {
    color: #409eff;
  }
}

.ai-evaluation, .manual-evaluation {
  margin-top: 16px;
  padding: 16px;
  background: #f5f7fa;
  border-radius: 4px;
  
  h5 {
    margin-bottom: 8px;
    color: #606266;
  }
  
  pre {
    white-space: pre-wrap;
    word-break: break-all;
    font-family: inherit;
    margin: 0;
  }
}
</style>